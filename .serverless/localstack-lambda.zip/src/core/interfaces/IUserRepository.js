"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IUserRepository.js.map