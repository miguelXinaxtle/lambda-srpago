"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Constants = void 0;
class Constants {
}
exports.Constants = Constants;
Constants.dynamoDBAPIVersion = "2012-08-10";
Constants.paramStoreAPIVersion = "2014-11-06";
Constants.duration = 120;
Constants.region = "us-west-2";
Constants.path = "/myfirstlambda/";
//# sourceMappingURL=Constants.js.map