"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Helper = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
class S3Helper {
    constructor() { }
    get(bucket, key) {
        return new Promise(function (resolve, reject) {
            try {
                const s3 = new aws_sdk_1.default.S3({
                    accessKeyId: "SRPAGOTEST",
                    secretAccessKey: "SRPAGOTEST",
                    region: "us-east-1",
                });
                s3.getObject({ Key: key, Bucket: bucket })
                    .promise()
                    .then((res) => {
                    var _a;
                    console.log("res=>", res.Body);
                    if (res.Body)
                        resolve((_a = res.Body) === null || _a === void 0 ? void 0 : _a.toString());
                })
                    .catch((err) => reject(JSON.stringify(err)));
            }
            catch (err) {
                reject("12");
            }
        });
    }
}
exports.S3Helper = S3Helper;
//# sourceMappingURL=S3Helper.js.map