"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const S3Helper_1 = require("./../framework/util/S3Helper");
require("reflect-metadata");
const handler = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    let res = "1";
    try {
        const s3Helper = new S3Helper_1.S3Helper();
        res = "2";
        res = yield s3Helper.get("onexlab", "test.json");
    }
    catch (err) {
        console.log(err);
        console.info(err);
        res = "20: " + JSON.stringify(err);
    }
    const response = {
        statusCode: 200,
        body: JSON.stringify({
            success: res,
        }),
    };
    return response;
});
exports.handler = handler;
//# sourceMappingURL=CreateUser.js.map